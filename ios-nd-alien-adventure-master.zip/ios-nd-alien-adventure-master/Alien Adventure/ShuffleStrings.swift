//
//  ShuffleStrings.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 9/30/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func shuffleStrings(s1 s1: String, s2: String, shuffle: String) -> Bool {
        
        //Tests to see if all the strings are empty, in which case, return true
        if s1 == "" && s2 == "" && shuffle == "" {
            return true
        }
        
        //Sets up constants for the length of the strings
        let s1Length: Int = s1.characters.count
        let s2Length: Int = s2.characters.count
        let shuffleLength: Int = shuffle.characters.count
        
        //Tests to see if the two smaller strings collectively have the same amount of characters as the shuffle string
        if s1Length + s2Length != shuffleLength {
            return false
        }
        
        //Variables for keeping track of how far the strings have matched up so far
        var s1Count: Int = 0
        var s2Count: Int = 0
        
        //Makes arrays of characters that are in the strings so we can keep an index
        var s1Array = [Character]()
        var s2Array = [Character]()
        for c in s1.characters {
            s1Array.append(c)
        }
        for c in s2.characters {
            s2Array.append(c)
        }
        
        //Algorithm for parsing through to see if the shuffle is valid or not
        for c in shuffle.characters {
            if s1Count != s1Length {
                print(s1Array[s1Count])
                if c == s1Array[s1Count] {
                    s1Count += 1
                }
            }
            if s2Count != s2Length {
                print(s2Array[s2Count])
                if c == s2Array[s2Count] {
                    s2Count += 1
                }
            }
        }
        
        //Checks if both strings had all characters in the shuffle string and 
        //if they were in order. This is done by the previous algorithm only adding
        //to s_Count if the character was in a valid shuffle order. If the count number
        //matches the string length, the whole thing passed the validity test
        if (s1Count == s1Length && s2Count == s2Length) {
            return true
        }
        
        return false
        
    }
}