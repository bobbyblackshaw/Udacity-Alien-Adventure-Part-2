//
//  OldestItemFromPlanet.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 10/3/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func oldestItemFromPlanet(inventory: [UDItem], planet: String) -> UDItem? {
        let planetItems = itemsFromPlanet(inventory, planet: planet)
        
        var oldestItem: UDItem? = nil
        
        if planetItems.count > 0 {
            oldestItem = planetItems[0]
            for item in planetItems {
                if item.historicalData["CarbonAge"] as! Int >= oldestItem!.historicalData["CarbonAge"] as! Int {
                    oldestItem = item
                }
            }
        }
        
        return oldestItem
    }
    
}

// If you have completed this function and it is working correctly, feel free to skip this part of the adventure by opening the "Under the Hood" folder, and making the following change in Settings.swift: "static var RequestsToSkip = 2"