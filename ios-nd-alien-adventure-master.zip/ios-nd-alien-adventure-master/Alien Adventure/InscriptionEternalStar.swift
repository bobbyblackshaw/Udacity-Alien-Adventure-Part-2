//
//  InscriptionEternalStar.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 9/30/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func inscriptionEternalStar(inventory: [UDItem]) -> UDItem? {
        var isInscription: Bool
        for item in inventory {
            if item.inscription != nil {
                isInscription = (item.inscription!.containsString("THE ETERNAL STAR"))
                if isInscription {
                    return item
                }
            }
        }
        return nil
    }
}
