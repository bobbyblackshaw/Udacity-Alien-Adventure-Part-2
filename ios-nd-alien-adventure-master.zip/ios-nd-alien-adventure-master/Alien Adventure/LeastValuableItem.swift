//
//  LeastValuableItem.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 9/30/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func leastValuableItem(inventory: [UDItem]) -> UDItem? {
        let checkedInventory: [UDItem]? = inventory
        if checkedInventory != nil{
            //I feel like putting 100 here is not the best way to do it. Could you offer me advice on a better way?
            var lowestValue = 100
            for item in checkedInventory! {
                if item.baseValue <= lowestValue {
                    lowestValue = item.baseValue
                }
            }
            for item in checkedInventory! {
                if item.baseValue == lowestValue {
                    return item
                }
            }
        }
        return nil
    }
}
